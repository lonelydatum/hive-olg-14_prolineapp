

import {dom, rotate} from '../../_common/js/PROLINE.js'


import {start, end, tl} from '../../_common/js/BB.js'

start()
tl.to(dom.phoneMain, .4, {y:-46}, 'end')
end()